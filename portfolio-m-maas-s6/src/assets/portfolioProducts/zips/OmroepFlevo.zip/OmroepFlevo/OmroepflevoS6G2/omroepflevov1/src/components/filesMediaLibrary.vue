<template>
  <div class="gridView">
                <v-layout column>
                  <v-flex xs12>
                    <div >
                      <v-layout>
                        <div class="item elevation-2">
                            
                        </div>                
                        <div class="item elevation-2">
                            
                        </div>
                        <div class="item elevation-2">
                            
                        </div>
                        <div class="item elevation-2">
                            
                        </div>
                      </v-layout>
                    </div>
                    <div>
                      <v-layout>
                        <div class="item elevation-2">
                            
                        </div>
                        <div class="item elevation-2">
                            
                        </div>
                        <div class="item elevation-2">
                            
                        </div>
                        <div class="item elevation-2">
                            
                        </div>
                      </v-layout>
                    </div>
                    <div>
                      <v-layout>
                        <div class="item elevation-2">
                         
                          
                        </div>
                        <div class="item elevation-2">
                          
                        </div>
                        <div class="item elevation-2">
                         
                        </div>
                        <div class="item elevation-2">
                          
                        </div>
                      </v-layout>
                    </div>
                    <div>
                      <v-layout>
                        <div class="item elevation-2">
                          
                        </div>
                        <div class="item elevation-2">
                          
                        </div>
                        <div class="item elevation-2">
                          
                        </div>
                        <div class="item elevation-2">
                          
                        </div>
                      </v-layout>
                    </div>
                  </v-flex>
                </v-layout>
              </div>
</template>

<script>
export default {
    name: 'filesMediaLibrary',
    data() {
        return {
        
    };
  },
}
</script>

<style>
    /* Media library grid view */
  .gridView {
    padding: 36px;
  }
  .item {
  min-height: 193px;
  min-width: 193px;
  margin: 24px;
}
</style>