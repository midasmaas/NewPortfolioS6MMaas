<template>
  <v-container>
    <h1>MediaView</h1>
    <Twitter></Twitter>
  </v-container>
</template>

<script>
import Twitter from '../../components/Twitter.vue';
export default {
  name: 'MediaView',
  components: {
    Twitter
  },
};


</script>
