<template>
<div>
  <hello-world />
</div>

</template>

<script>
import HelloWorld from '../components/HelloWorld.vue';

export default {
  name: 'homeView',
  components: {
    HelloWorld,
  },
};
</script>
