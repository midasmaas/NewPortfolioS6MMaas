<template>
<v-container>
  <h1>
    ListsView
  </h1>
</v-container>

</template>

<script>

export default {
  name: 'ListView',
};
</script>
